const { defineConfig } = require('@vue/cli-service')
module.exports = defineConfig({
  transpileDependencies: true,
  publicPath: './',
  pages: {
    index: {
      entry: 'src/main.js',
      template: 'public/index.html',
      filename: 'index.html',
      title:"点滴 » RedSpite Simon个人学习小站",
      icon:"https://red-spid.github.io/resources/icon/"
    }
  }

})