/*
 * vuex 的声明 
 */

import { createStore }  from "vuex";
// import state from "./store/index.js";
import dataJson from "../../json/index.js";

import getters from "./getters/index.js";
import mutations from "./mutations/index.js";
import actions from "./actions/index.js";
import module from "./module/index.js";

if( window.navigator.onLine ){
  console.log("在线")
}else{
  console.log("离线");
  // dataJson.origin = "";
  // dataJson.image = "@/assets/";
  // dataJson.music = "";

}
// console.log(dataJson,'----------------------111'  )
const store = createStore({
  state:dataJson,
  getters,
  mutations,
  actions: actions,
  module
})
console.log( store )

export default store;