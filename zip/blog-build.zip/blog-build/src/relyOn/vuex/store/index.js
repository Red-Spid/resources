import dataJson from "../../../json/index";

export default {
    dataJson
}