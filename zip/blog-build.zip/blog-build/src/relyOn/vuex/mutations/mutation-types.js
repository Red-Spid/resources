// mutation-types.js

export const COMPUTE_DATE = 'COMPUTE_DATE';
export const INCREMENT = 'INCREMENT';
export const FOR_LIST = 'FOR_LIST';

