
/**
 *  2及公共数据
 */


import moduleA from "./class/a.js";
import moduleB from "./class/b.js";


export default {
    moduleA,moduleB
}