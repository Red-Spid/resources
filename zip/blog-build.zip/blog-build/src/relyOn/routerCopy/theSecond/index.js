export default{
    name:"detall", path: "/detail",
    component: () => import('../../../views/LeavingAmessage/'),
}