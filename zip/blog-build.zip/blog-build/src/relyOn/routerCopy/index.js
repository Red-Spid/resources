
import { createRouter, createWebHashHistory } from 'vue-router'

import theSecond from "./theSecond";

const routes = [

  {
    path: "/", name: "home", redirect: "/personal/dropBYdrop",
  },
  {
    name: "personal",
    path: "/personal",
    component: () => import('@/views/personal/'),
    children: [
      {
        path: 'resume',
        name: "resume",
        component: () => import('@/views/TechnologySharing/')
      },
      {
        path: 'dropBYdrop',
        name: "dropBYdrop",
        // LeavingAmessage
        component: () => import('@/views/dropBYdrop/')
      },
      {
        path: 'comments',
        name: "comments",
        // shareExperience
        component: () => import('@/views/LeavingAmessage/')
      }
    ]
  },
  {
    path: "/detail", name: "detail",
    component: () => import('@/views/detail/')
    // redirect: "/detail",
  },
  theSecond,
]

const router = createRouter({
  history: createWebHashHistory(),
  routes
})

export default router
