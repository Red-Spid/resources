import { createApp } from 'vue'
import App from './App.vue'
import vuex from './relyOn/vuex'
// import router from './relyOn/router'
import router from './relyOn/routerCopy'
import add from '@/components';

// document.addEventListener('DOMContentLoaed', function(){
//     console.log("DOMContentLoaed","-----------------")
// })

createApp(App).use(add).use(router).use(vuex).mount('#app');