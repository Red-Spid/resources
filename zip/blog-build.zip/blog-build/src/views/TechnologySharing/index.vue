<template>
  <div>

    <sharing :infor="$store.state.personalInformation" name="1"/>

  </div>
</template>
<script>
export default {
  name: "TechnologySharing",
};
</script>