<template>
  <div>
    
    <amessage :data="$store.state.comments" :list=" $store.state.commentsUer " :isdom=" $store.state.signIn "/>
  </div>
</template>
<script>
export default {
  name: "LeavingAmessage",
};
</script>