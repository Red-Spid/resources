<template>
  <div class="w-100">
    <!-- Math.floor(Math.random() * (10000000 - 1)) + 1 -->
    <svg-git />
    <github-tip @myEvent="refreshView" :refreshImg="refreshImg" />
    <!-- <home /> -->
    <suspension-bar/>

    <router-view/>

  </div>
</template>
<script>
export default {
  name: "PersonaL",
  data() {
    return {
      refreshImg:true,
    }
  },
  methods:{
    refreshView(){
      this.refreshImg = false;
      setTimeout(()=>{
        this.refreshImg = true;
      },100)
    }
  }
};
</script>