<template>
  <div class="w-100">

    <svg-git />
    <github-tip />
    <!-- <home /> -->

  </div>
</template>
<script>
export default {
  name: "HomeIndex",
  mounted() {
    console.log(this)
  },
};
</script>
