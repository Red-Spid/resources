<template>
    <view>
        <!-- 日历 -->
        <date></date>

    </view>
</template>
<script>
import md5 from 'js-md5';
export default {
  name: "DETAIL",
  data() {
    return {
      drop:""
    }
  },
  mounted(){
      console.log(
        md5('11111'),"1111"
      )

      console.log(
          this.$route.query
      )
  }
};
</script>