<template>
  <div>
    
    <drop :drop="drop" />
  
  </div>
</template>
<script>
export default {
  name: "dropBYdrop",
  data() {
    return {
      drop:""
    }
  },
  mounted:function(){
    this.drop = this.$store.state.dropBYdrop
    console.log(this.drop )  
  }
};
</script>