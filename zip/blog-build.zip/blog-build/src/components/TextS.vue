<template>
    <div>
        <a href="" class="cc">texts.vue</a>
    </div>
</template>
<script>
export default {
    name:"TextS"
}
</script>