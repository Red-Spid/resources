<template>
  <div class="Header">
    
    <div class="fadein" v-if="refreshImg">
      <img :src="my.headportrait" />
    </div>

    <div class="head_name">
      <p v-text="my.name"></p>
    </div>
    
    <div class="my_sort">
      <ul>
        <!-- :class="[$route.name == item.name ? 'active' : '11']" -->
        <li
          v-for="(item, index) in list"
          :key="index"
          :class="[$route.name == item.name ? 'active' : '11']"
          @click="afterView( index )"
        >
          <router-link :to="item.url " v-text="item.text"></router-link>
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
export default {
  name: "GithubTip",
  props: {
    msg: String,
    refreshImg:[Boolean]
  },
  data() {
    return {
      my: "",
      list: "",
    };
  },
  directives: {
    trigger: {
      // inserted(el) {
        // console.log(el, binging,'??????')
        // el.id == "nav0" ? el.click() : null; // 只点击第一个，id是在循环中手动添加的
        // $(el).trigger('click')  // 所有都触发一次,然后就是最后一个
      // },
    },
  },
  methods:{
    afterView(index){
      this.$store.dispatch('forlist', index);
      this.$emit('myEvent')
    },
    routerPush( url="", query={}, params={} ){
      this.$router.push(
        {
          path:url,
          query:query,
          params:params
        }
      )
// @click="$store.dispatch('forlist', index)"
    }
  },
  mounted() {
    // console.log(this.$route,'-----------',this.$route.name)
    this.my = this.$store.state.my;
    this.my.url =
      this.$store.state.my.url == "selfRouting"
        ? this.$store.state.selfRouting
        : this.$store.state.my.url;

    this.list = this.$store.state.list;
    // console.log( this.my )
  },
};
</script>