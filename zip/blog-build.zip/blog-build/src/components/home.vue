<template>
  <div class="w-100">

    <swiper :modules="[EffectFade]" effect="fade">

      <swiper-slide>
        
      </swiper-slide>
      <swiper-slide>
        
      </swiper-slide>
      <swiper-slide>
        
      </swiper-slide>

    </swiper>

    <!-- <keep-alive> -->
        <!-- <technology-sharing :infor="$store.state.personalInformation" name="1" />  -->
    <!-- </keep-alive> -->
    <!--  <technology-sharing :infor="$store.state.personalInformation" name="1" /> -->
    <!-- <dropBYdrop :data="$store.state.dropBYdrop"/> -->
    <!-- <leaving-amessage :data="$store.state.comments" :list=" $store.state.commentsUer " :isdom=" $store.state.signIn "/> -->
  </div>
</template>
<script>
import { EffectFade } from "swiper";
import { Swiper, SwiperSlide } from "swiper/vue";

import "swiper/css";
import "swiper/css/effect-fade";
export default {
  name: "HomeVue",
  components: {
    Swiper,
    SwiperSlide,
  },
  setup() {
    return {
      EffectFade,
    };
  },
};
</script>
<style scoped>
</style>