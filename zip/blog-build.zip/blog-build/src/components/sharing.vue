<template>
  <div class="page bodyHtml" ref="add">
    <section v-for="(val, index) in infor" :key="index">
      <h1 v-text="val.name"></h1>

      <div class="content pa boxes">
        <template v-for="(jacketed, layer) in val.arr" :key="layer">
          <div :class="[ pirce.length >= 2 ? 'box points' : 'box thatSok']" v-for="(pirce, bolt) in jacketed" :key="bolt">
            <!-- <article> -->
            <div v-for="(value, key) in pirce" :key="key" class="clo4">
              
              <text v-if="!value.url && value.bold != true"
                :title="
                  value.tips +
                  (value.sex
                    ? val.push + value.sex + val.push
                    : value.push
                    ? value.push
                    : val.push) +
                  value.val
                "
              >
                {{
                  value.tips +
                  (value.sex
                    ? val.push + value.sex + val.push
                    : value.push
                    ? value.push
                    : val.push) +
                  value.val
                }}
              </text>

              <div v-else-if="value.url && value.bold != true">
                {{
                  value.tips +
                  (value.sex
                    ? val.push + value.sex + val.push
                    : value.push
                    ? value.push
                    : val.push)
                }}
                <a
                  :href="
                    value.url == 'selfRouting'
                      ? $store.state[value.url]
                      : value.url
                  "
                  target="_blank"
                  class="hrefurl"
                  :title="
                    value.val == 'selfRouting'
                      ? $store.state[value.url]
                      : value.val
                  "
                >
                  {{
                    value.val == "selfRouting"
                      ? $store.state[value.val]
                      : value.val
                  }}</a
                >
              </div>

              <div v-else-if="value.bold == true">
                <b>{{ value.val }}</b>
              </div>
            </div>
            <!-- </article> -->
          </div>
        </template>
      </div>
    </section>
  </div>
</template>
<script>
export default {
  name: "TechnologySharing",
  props: ["infor"],
  data() {
    return {
      info: "",
    };
  },
  created() {
    console.log(this.$attrs);
    // console.log(this.$listeners)
  },
  mounted() {
    //  console.log(this.$route.params)
  },
  methods: {
    aaa() {},
  },
};
</script>