
/*
require.context是webpack中用来管理依赖的一个函数,此方法会生成一个上下文模块，包含目录下所有的模块的引用，同构正则表达式匹配,然后require进来
 */
const allComponents = require.context('./', false, /\.vue$/);
let res_components = {}
// 导入所有组件
// 以 "dialog-" 开头,以".vue"结尾
allComponents.keys().forEach(fileName => {
    let comp = allComponents(fileName)
    res_components[fileName.replace(/^\.\/(.*)\.\w+$/, '$1')] = comp.default
})
console.log(res_components);

function plugin(Vue){
    if( plugin.installed ){
        return
    }
    for(let i in res_components){
        // console.log( res_components[i] )
        Vue.component(i,res_components[i])
    }

}
export default plugin;
// export default {
//     name: 'purchase',
//     components: res_components,
// }
