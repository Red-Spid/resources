<template>
	<view class="content">
		{{count}}
		<view class="tips p20">
			<!-- <image @click="reduce" class="img" src="@/static/left-icon.png" mode=""></image> -->
			<button @click="reduce">左</button>
			<text class="bold" v-text="year + '年' + month + '月'"></text>
			<button @click="plus">右</button>
			<!-- <image @click="plus" class="img" src="@/static/right-icon.png" mode=""></image> -->
		</view>

		<view class="weeb p20 space_etween"><text class="weeb_length" v-for="(item, index) in weeks" :key="index"
				v-text="item"></text></view>

		<view class="zoow p20">
			<view class="zoow_text" v-for="(val, key) in first_date" :key="key + 'a'"></view>

			<view :class="[
          date > index + 1 ? 'zoow_text' : 'zoow_text _green',
          fouce[index] ? 'zoow_text_focus' : '',
        ]" v-for="(item, index) in zoow" :key="index" @click="fouceadd(index)">
				<text class="first">{{ item }}</text>
				<text :class="date > index ? '' : 'money'">￥2450</text>
			</view>

			<view class="zoow_text" v-for="(val, key) in last_date" :key="key + 'a'"></view>
		</view>
	</view>
</template>

<script>
export default {
  name: "DATE",
  data() {
    return {
      title: "Hello",
      year: "", // 年份
      month: "", // 月份
      data: "", // 日
      day: "", // 周几
      weeks: ["日", "一", "二", "三", "四", "五", "六"],
      zoow: "",
      arr: [],
      d: new Date(),
      fouce: [],
      first_date: "",
      last_date: "",
      initialMonth: "",
    };
  },
  watch: {
    month: {
      handler(newName, oldName) {
        console.log(
          newName,
          oldName,
          this.gfullYear,
          "111111111111111111111111111111"
        );
      },
    },
  },
  mounted() {
    this.demoFirst();
  },
  methods: {
    reduce: function () {
      this.updateMonth_Date(false);
    },

    plus: function () {
      this.updateMonth_Date(true);
    },

    updateMonth_Date: function (e) {
      if (e && this.initialYear >= this.year) {
        this.month++;
        this.date = 0;
      } else {
        this.month--;
        if (this.initialYear >= this.year && this.initialMonth >= this.month) {
          this.date = 100;
        }
      }
      if (this.month == 13) {
        this.year++;
        this.month = 1;
      } else if (this.month == 0) {
        this.year--;
        this.month = 12;
      }
      if (this.initialYear == this.year && this.initialMonth == this.month) {
        this.demoFirst();
        return;
      }

      this.first_date = new Date(
        this.year + "/" + this.month + "/" + 1
      ).getDay();
      this.last_date = new Date(
        this.year + "/" + (this.month + 1) + "/" + 1
      ).getDay();
      this.zoow = new Date(this.year, this.month, 0).getDate(); // 一个月多少天
      // console.log(this.first_date, this.year, this.zoow);
    },

    fouceadd: function (e) {
      for (let i = 0; i < this.fouce.length; i++) {
        if (e == i) {
          this.fouce[e] = true;
        } else {
          this.fouce[i] = false;
        }
      }
      // console.log(e);
      // console.log(this.fouce[e]);
      this.$forceUpdate();
    },

    demoFirst: function ( d = new Date() ) {
      let weeks = new Array("日", "一", "二", "三", "四", "五", "六");
      let gfullYear = d.getFullYear(); // 年份
      this.year = gfullYear;
      this.initialYear = gfullYear;
      let gmonth = d.getMonth() + 1; // 月份
      this.initialMonth = gmonth;
      this.month = gmonth;
      let gdate = d.getDate(); // 几号
      this.date = gdate;
      this.first_date = new Date(gfullYear + "/" + gmonth + "/" + 1).getDay(); // 周几
      this.last_date = new Date(
        gfullYear + "/" + (gmonth + 1) + "/" + 1
      ).getDay();

      let zoow = new Date(gfullYear, gmonth, 0).getDate(); // 一个月多少天
      let first_zoow = new Date(gfullYear, gmonth - 1, 0).getDate(); // 一个月多少天
      this.first_zoow_date = new Date(
        gfullYear + "/" + (gmonth - 1) + "/" + first_zoow
      ).getDay(); // 周几

      this.zoow = zoow;
      let gday = weeks[d.getDay()]; // 周几
      this.day = gday;
      console.log( "本月第一天 是周几 -------》" + weeks[this.first_date] )
      console.log( "下个月第一天 是周几 -------》" + weeks[this.last_date] )

      console.log(
        "上个月是多少天" + first_zoow,
        "上个月最后一天是周几------》" + this.first_zoow_date,
        "今天是本月的几号-------》" + this.date,
        "本月多少天-----》" + zoow
      );
    },
  },
};
</script>




<style scoped>
	.zoow_text {
		color: rgb(107, 90, 90);
		/* background-color:#fff; */
		justify-content: center;
	}

	._green {
		color: #000;
		font-weight: bold;
		/* background-color:#eee; */
	}

	.p20 {
		padding: 0.2rem 0;
	}

	.weeb {
		color: rgb(0, 0, 0);
	}

	.weeb .weeb_length:first-child,
	.weeb .weeb_length:last-child {
		color: rgb(169, 162, 162);
	}

	.bold {
		font-weight: bold;
		font-size: 0.36rem;
	}

	.first {
		line-height: 0.24rem;
	}

	.zoow_text {
		flex: 1 1 14.285714285714286%;
		display: flex;
		flex-direction: column;
		height: 1rem;
	}

	.weeb_length {
		flex: 1;
	}

	.space_etween {
		display: flex;
		justify-content: space-between;
	}

	.zoow {
		display: flex;
		flex-wrap: wrap;
	}

	.content {
		display: flex;
		flex-direction: column;
		/* background: url(https://red-spid.github.io/resources/image/Cproject/paper.gif); */
		background-color: #ddd;
	}
</style>
